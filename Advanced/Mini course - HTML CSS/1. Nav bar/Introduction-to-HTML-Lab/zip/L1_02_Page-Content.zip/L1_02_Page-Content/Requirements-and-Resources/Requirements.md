﻿# 02 - Page Content
------
Problems for the [“HTML and CSS”](#) course @ **SoftUni**

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the **title**
* Use **section** tag to create a section
* Use an **h1** tag for the section title
* Use **article** tag and create **two** articles inside the section
    * Each **article** has a **header** and a **paragraph**
    * Each **header** has an **h3** title and a **paragraph**